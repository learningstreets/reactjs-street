import { React } from 'react';
import ReactDom from 'react-dom';
import logo from './logo.svg';
import './index.css';

// Creating an constant to just hold some value - Beautifuly we can have tags in that 
// Okay so Babel will convert this below into React element hence we have imported React at top.
// It will look like: React.createElement...
const element = (

    <div className="App-header">
        <img src={logo} className="App-logo" alt="Logo" />
        <div className="App-heading">  Hello World</div>
    </div>
);

// React object gets saved into vairtual dom hence need to create a actual dom which will hold are react object
// Okay so now below is a creation of DOM which looks for the element and the container to display
ReactDom.render(element, document.getElementById('root'))
